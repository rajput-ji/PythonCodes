# set of unon and intersection 
a = {10, 20, 100, 50}
b = {10, 20, 30}
c = a.union(b)
print(len(c))

a = {10, 20, 30, 50}
b = {10, 20, 50, 60}
c = a.intersection(b)
print(c)