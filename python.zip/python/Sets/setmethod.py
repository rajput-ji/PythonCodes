# let us find length of set
# hear length is not count repeat values
data = {10, 200, 100, 10}
print(len(data))

# get  copy the data
set = {20, 10, 30, 50}
copy = set.copy()
print(copy)