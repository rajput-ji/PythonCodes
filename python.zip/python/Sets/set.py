# set is unorder collection of element
# set does not support item assign and index
data = {'a', 'e', 'd', 'i'}
print(data)
del data


#Get a character from the user and check whether the character present in below set or not. 

#if present, Print "Yes"

#Otherwise, Print "No"
data = {'a', 'e', 'i', 'o', 'u'}
num = input()
if num in data:
    print("Yes")
else:
    print("No")