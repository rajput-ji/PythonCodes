# subset, superset, disjoint, difference, union, symmetric_difference
a = {10, 20, 30, 40}
b = { 10, 20, 50, 60}
print(a.issuperset(b), b.issuperset(a))

a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
b = {2, 4, 6, 8}
print(a.issuperset(b), b.issuperset(a))

a = {1, 2, 3, 100}
b = {3, 20, 50, 100}
print(a.union(b))
print(a.difference(b))
print(a.symmetric_difference(b))