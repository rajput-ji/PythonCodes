# set.add(), set.remove(), set.update(), set.clear(), 
data = {10, 200, 100, 500, 2000}
data.update({100, 5})
num = int(input())
data.remove(num)
print(data)