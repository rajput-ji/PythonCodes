# change the value
data = {"name":"Mohit", "Age":18, "sub":"Programing", "num":5}
data["Age"] = 20
var = "Age"
if var in data:
    print(data[var])
else:
    print("key is not found")

# Add new item
data["sir"] = "Singh"
print(data)

# REMOVE ITEMS
del data["sir"]
print(data)

# clear data
data.clear()
print(data)

# delete dictionary
del data