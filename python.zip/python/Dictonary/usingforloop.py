# access the element uasing for loop 
# thare are 3 types to access the element using for loop 
# and its  function is 
# 1st dictionary.keys, dictionary.values, dictionary.items 

data = {"name":"Mohit", "Age":18, "sub":"Programing", "num":5}

# dictionary,keys is use to access all keys in dictionary 
for x in data.keys():
    print(x)

# dictionary.values is use to access all values in dictionary
for x,y in data.items():
    print(x,y)
    
# dictionary.items i use to access the all items in dictionary
for x in data.values():
    print(x)