# How to access the dictonary item
data = {"name":"Mohit", "Age":18, "sub":"Programing", "num":5}
print(data.get("name"))
print(data.get("Age"))

# chek if key is present or not in dictonary
var = "apple"
if var in data:
    print(data[var])
else:
    print("key is not found")

var = "name"
if var in data:
    print(data[var])
else:
    print("key is not found")
