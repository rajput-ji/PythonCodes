# lets check how to find length of dictionary
data = {"name":"Mohit", "Age":18, "sub":"Programing", "num":5}
print(len(data))

# how to copy the dictionary: 
data = {"name":"Mohit", "Age":18, "sub":"Programing", "num":5}
copy = dict[data]
print(copy)