# Hear slicing of string 
# default value is 0 and end of string value.
str = "Python"
print(str[:5])


str = "Python"
print(str[3:6])

