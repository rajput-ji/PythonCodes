# in string methods the len function count every words and blank space
# Hear split() function is use to splite the words 
# example:      Mohit Singh
#   in split    ['mohit','singh'] 

str = "Mohit Singh Rajput"
print(len(str))


str = "The words present in this string are separated by white space."
#Write your code here
word_list = str.split()
num_words = len(word_list) 
print(num_words)

# Hear replace is use for replace the words and white spaces
str = input()
new_str = str.replace(" ","_")
print(new_str)