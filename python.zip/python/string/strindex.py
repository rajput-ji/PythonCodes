# Hear python string index is start from 0 and reverse index is start from -1
#example    0   1   2   3   4   5
#           p   Y   T   H   O   N
#           -6  -5  -4  -3  -2  -1

str = "Python"
print("Access First charactor ", str[0])
print("Access Last charactor ", str[5])

print("Access First charactor ", str[-5])
print("Access last charactor ", str[-1])