str = input()
c = input()
if c in str:
    print("Yes")
    
else:
    print("No")