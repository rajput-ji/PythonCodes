num1 = int(input("Enter the first value"))

if num1 <= 10:
    print("yes")

# hear if is 1 condition 