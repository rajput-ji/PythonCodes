if True :
    print("One")    
elif True :
    print("Two")
else :
    print("Three")