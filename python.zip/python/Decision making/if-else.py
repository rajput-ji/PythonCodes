num1 = int(input("enter first value"))

if num1 <= 10:
    print("Yes is less or equel")
else:
    print("no is greater")