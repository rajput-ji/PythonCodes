# List in Python
# Create a list in python and also check if number present in list
# hear we does not put "" in number hear access number in list automatically

list = [10, 20, 30, 4.50, 60]
if 4.50 in list:
    print("Yes")
else:
    print("No")