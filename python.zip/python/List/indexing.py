# Hear access the list index 
#example    0    1   2   3   4   5
#           [100  10  5   3  2O   12]
#           -6  -5  -4  -3  -2  -1

numbers = [10, 20, 30, 40, 50, 60, 70]
#Write your code here
numbers[2] = 1000
print(numbers)
