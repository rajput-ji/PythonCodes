# How to add elements in list
# hear inserting function is list.insert()
# in inserting function you shoud write index of number,element
num = [10, 20, 30, 40, 50]
num.insert(2,100)
print(num)

num = [10, 20, 30, 40, 50]
num.append(1000)
print(num)

# Removing element from list
# hear remove the elemet in list to use del function 
# syntax is:     del list[index]
num = [10, 20, 30, 40, 50]
del num[0]
print(num)

# Clear the list
num = [10, 20, 30, 40, 50]
num.clear()
print(num)

# delete the list
num = [10, 20, 30, 40, 50]
del num
print(num)  
#hear error show because list is deleted

