# hear slicing the list it is similer to string slicing

num = [10, 20, 30, 40, 50, 60, 70]
print(num[3:6])
print(num[2:5])

# How to remove the element in list
# hear write list name and select the remove element index number to remove it
num[2:5] = []
print(num)
