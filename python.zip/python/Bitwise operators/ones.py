a = -2345
print(~a)

var = 20
print("value", ~var)

# aager value positive hai toh once complement me ye minus me 1 minus ho0n ke aata hai 
# or negative rha toh ye 1 positive ho ke aaye ga 
# example:  2345 = -2346,  -5 = 4