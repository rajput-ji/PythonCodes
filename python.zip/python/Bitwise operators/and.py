a = 12
b = 6

print(a & b)