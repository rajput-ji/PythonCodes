a = 8
b = (a >> 4) << 4

print(b)