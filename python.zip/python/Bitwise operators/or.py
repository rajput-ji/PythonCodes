a = 10
b = 5
ans = a | b
print(ans)