a = 100
ans = a << 1

print(ans)

# left-shift operator me us value ka dugna value hojata hai 
# # example:  20 = 40,  200 = 400, 50 = 100..... 