#Dynamic nature in python
i = 10
i = "Hello"
# Hear Dynamic nature ye khata hai ki old jo declarte kiya hai
#  same variable me wo change ho jayega new variable me
print(i)

i = 1.5
print(i)

# hear python read all code line by line that way here 
# print i is printing Hello and 1.5