
#escape functions
print(r"c:\\gadhabhai12\0")  #it is use for type as to as statement as special characters
print("Hello \t World ")   # use for tab like this  Hello      World
print("Hello \n World")     # use for new line 


