# print function 
 
print("Hello World")
print('"Hello World"')
print("'Hello World'")
print(10)
print('Hello World')