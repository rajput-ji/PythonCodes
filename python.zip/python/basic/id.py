a = 10
print(id(a))

# hear id is print the object of value
