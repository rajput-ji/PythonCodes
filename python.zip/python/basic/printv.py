#print value function in pythpon

name = "Mohit" 
age = 18 
print(f"my name is {name} and i ma {age} yers old")
print(name, age)