
a = 10
b = 4
print(a/b, a//b)