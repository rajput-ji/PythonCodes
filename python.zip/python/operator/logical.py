# Logical operator 
# Thare are three types of logical operator
# 1) and 
# 2) or
# 3) not
# this logical operators are based on truth table
