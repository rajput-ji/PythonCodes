# how to access disctonery using for loop
data = {"mohit":18, "Aman":20, "nikhil":18, "suraj":19}
