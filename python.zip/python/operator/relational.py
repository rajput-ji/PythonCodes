# Relational operator 
# hear relational operator is based on True & False
# operators
# ==
# !=
# <
# >
# <=
# =>

a = 10
b = 5
print(a == b)
print(a != b)
print(a > b)
print(a < b)
print(a >= b)
print(a <= b)
