# operators        meaning
#  +=               a = a + b
#  -=               a = a - b
#   /=              a = a / b
#   *=              a = a * b
#   **=             a = a ** b
#   //=             a = a // b
#   %=              a = a % b

a = 10
b = 20
b = a * b

print("Sum = ", b)
