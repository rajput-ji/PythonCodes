# Touple is not but same as list but it canot modified 
# let see how to access tha touple
data = (100, 200, 300)
print(data)

# italse have a index like list 