# Touple is immutable
# so hear we can't change any value of touple 
# hear only delet the touple function is runn 

data = (10, 20, 30)
del data