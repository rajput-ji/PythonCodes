data = (10, 20, 30, 40, 50, 60, 50)
print(data.index(50))


# Print how many times the value 10 is present in the below tuple.
data = (10, 20, 100, 300, 10, 35, 67, 10, 10)
#Write your code here
print(data.count(10))
