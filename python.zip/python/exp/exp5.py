
a = {'a', 'e', 'x', 'y', 'i', 'f', 'k', 'c'}
#Write your code here
vowel =  {'a', 'e', 'i', 'u'}
