i = 0

if i == 10:{
print("Yes")}
else:{
print("No")}
    # Hear use the comment line
    # to explain what the code is doing
    # and what the code is doing
    