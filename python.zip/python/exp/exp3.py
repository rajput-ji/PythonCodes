# print even or odd number 

num = int(input())
if (num % 2) == 0:
    print("Even")
else:
    print("Odd")