# Write a program to take input from user and print 2 value 
# output on screen like sum, sub, mul, div

a = int(input("enter the value"))
b = int(input("enter the value"))

sum = a+b
sub = a-b
mul = a*b
div = a/b

print("sum = ",sum)
print("sub = ",sub)
print("mul = ",mul)
print("div = ",div)