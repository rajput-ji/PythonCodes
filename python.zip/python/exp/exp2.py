# write a program to print 2 power of 10;
a = 2
b = 10
sum = a**b
print(sum)


# hear power mins (2^10) = 1024
