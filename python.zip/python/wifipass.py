import subprocess
meta_data = subprocess.check_output(['netsh','wlan','show','profiles'])
deta = meta_data.decode('utf-8',errors = "blackslahreplace")
data = data.split('\n')
profile = []
for i in data:
    if "all user profile" in i:
        i = i.split(":")
        i = i[1]
        i = i[1:-1]
        profile.append(i)
        print("{<30}|{:<}".format("WiFi Name","Password"))
        print("------------------------")
        for i in profile:
                result = subprocess.check_output(['netsh','wlan','show','profile',i,'key = clear'])
                result = result.decode('utf-8',error = "backslashreplace")
                result = result.split('\n')
                result = [b.split(":"[1][1:-1]for b in result if "key Content" in b)]
                try:
                    print("{:<30}|{:<}".format(i,""))
                except subprocess.CalledProcessError:
                    print("Encoding Error Occurred")